import { redirect } from 'next/navigation';
export default function Home() { redirect('/c/hq/announcements'); }
