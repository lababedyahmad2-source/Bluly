// Zero-cache service worker: satisfies PWA installability, stores nothing (phantom privacy).
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
