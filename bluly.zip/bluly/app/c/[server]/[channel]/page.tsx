import Workspace from '@/components/Workspace';

export default async function ChannelPage({ params }: { params: Promise<{ server: string; channel: string }> }) {
  const { server, channel } = await params;
  return <Workspace serverId={server} channelId={channel} />;
}
