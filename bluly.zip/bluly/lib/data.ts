export type Kind = 'broadcast' | 'thread';
export interface Server { id: string; name: string; glyph: string; verified: boolean }
export interface Channel { id: string; serverId: string; kind: Kind; name: string; purpose: string; parent?: string; urgent?: number }
export interface Media { kind: 'image' | 'video' | 'file'; name: string; bytes: number; src?: string }
export interface Msg { id: string; author: string; ts: string; text?: string; media?: Media }

export const SERVERS: Server[] = [
  { id: 'hq', name: 'Bluly HQ', glyph: 'HQ', verified: true },
  { id: 'lab', name: 'Open Source Lab', glyph: 'OS', verified: true },
  { id: 'owl', name: 'Night Owls', glyph: 'NO', verified: false },
];

export const CHANNELS: Channel[] = [
  { id: 'announcements', serverId: 'hq', kind: 'broadcast', name: 'announcements', purpose: 'Official platform news, pushed by the core team only.', urgent: 2 },
  { id: 'releases', serverId: 'hq', kind: 'broadcast', name: 'releases', purpose: 'Every build, changelog and rollback notice in one feed.' },
  { id: 'release-0-9', serverId: 'hq', kind: 'thread', name: 'release-0-9-feedback', parent: 'releases', purpose: 'Reply to the 0.9 release post: bugs, wins and regressions.', urgent: 5 },
  { id: 'security-notes', serverId: 'hq', kind: 'thread', name: 'key-rotation-qa', parent: 'announcements', purpose: 'Questions about the invite key rotation announced above.' },
  { id: 'changelog', serverId: 'lab', kind: 'broadcast', name: 'changelog', purpose: 'Merged pull requests and tagged versions, nothing else.' },
  { id: 'rfcs', serverId: 'lab', kind: 'broadcast', name: 'rfcs', purpose: 'Open proposals awaiting maintainer votes.', urgent: 1 },
  { id: 'rfc-12', serverId: 'lab', kind: 'thread', name: 'rfc-12-streaming', parent: 'rfcs', purpose: 'Debate the streaming parser proposal.' },
  { id: 'drops', serverId: 'owl', kind: 'broadcast', name: 'drops', purpose: 'Late-night file drops from the members.' },
  { id: 'drop-talk', serverId: 'owl', kind: 'thread', name: 'drop-talk', parent: 'drops', purpose: 'Talk about whatever was dropped above.' },
];

export const firstChannel = (serverId: string) => CHANNELS.find((c) => c.serverId === serverId && c.kind === 'broadcast')!.id;
export const fmtBytes = (b: number) => (b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
export const ext = (n: string) => (n.includes('.') ? n.split('.').pop()!.toUpperCase() : 'FILE');
export const nowTs = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

const MB = 1048576;
export const SEED: Record<string, Msg[]> = {
  announcements: [
    { id: 'a1', author: 'core', ts: '08:02', text: 'Invite keys rotate every 30 days. Old keys stop working at 00:00 UTC on the 1st.' },
    { id: 'a2', author: 'core', ts: '08:03', text: 'Media never auto-loads on Bluly. You choose what downloads, and when.' },
    { id: 'a3', author: 'core', ts: '09:41', media: { kind: 'video', name: 'infra-walkthrough.mp4', bytes: 14.2 * MB } },
    { id: 'a4', author: 'core', ts: '09:44', text: 'Walkthrough above covers the new edge routing. Ask questions in the thread.' },
  ],
  releases: [
    { id: 'r1', author: 'build-bot', ts: '11:20', text: 'v0.9.0 shipped. Bundle size down 18%. Zero new dependencies.' },
    { id: 'r2', author: 'build-bot', ts: '11:21', media: { kind: 'image', name: 'bundle-diff.png', bytes: 2.4 * MB } },
  ],
  'release-0-9': [
    { id: 't1', author: 'mira', ts: '11:30', text: 'Cold start feels instant on my phone. Great work.' },
    { id: 't2', author: 'oleg', ts: '11:34', text: 'Found a focus-ring clipping bug in the composer on Safari.' },
    { id: 't3', author: 'mira', ts: '11:36', media: { kind: 'image', name: 'safari-focus-bug.png', bytes: 860 * 1024 } },
  ],
  changelog: [{ id: 'c1', author: 'maintainer', ts: '07:12', text: 'Tagged 3.2.1: fixes tokenizer panic on empty input.' }],
  rfcs: [{ id: 'f1', author: 'maintainer', ts: '10:00', text: 'RFC-12 is open for comments until Friday.' }],
  drops: [{ id: 'd1', author: 'nox', ts: '02:14', media: { kind: 'video', name: 'rooftop-set.mov', bytes: 88.9 * MB } }],
};
