'use client';
import { useState } from 'react';
import { ext, fmtBytes, type Media } from '@/lib/data';
import Icon from './Icon';

const LABEL = { image: 'Image', video: 'Video', file: 'File' } as const;
const mockSvg = (name: string) =>
  'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="480" height="270"><rect width="100%" height="100%" fill="#1E2229"/><text x="50%" y="50%" fill="#94A3B8" font-family="sans-serif" font-size="16" text-anchor="middle">${name.replace(/[<>&]/g, '')}</text></svg>`);

/** Nothing is parsed, decoded or fetched until the user presses the download button. */
export default function MediaBlock({ m }: { m: Media }) {
  const [src, setSrc] = useState<string | null>(null);
  const mount = () => setSrc(m.src ?? (m.kind === 'image' ? mockSvg(m.name) : 'mock'));

  return (
    <div className="mt-1 w-full max-w-sm rounded-md border border-line bg-surface p-3">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded bg-base text-electric"><Icon n={m.kind} s={20} /></span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-white">{m.name}</p>
          <p className="text-xs text-muted">{ext(m.name)} • {fmtBytes(m.bytes)}</p>
        </div>
      </div>
      {src === null ? (
        <button onClick={mount} className="mt-3 flex w-full items-center justify-center gap-2 rounded bg-electric py-2 text-sm font-semibold text-white hover:bg-white hover:text-base">
          <Icon n="dl" s={16} />Download {LABEL[m.kind]}
        </button>
      ) : (
        <div className="mt-3">
          {m.kind === 'image' && /* eslint-disable-next-line @next/next/no-img-element */ <img src={src} alt={m.name} className="max-h-72 w-full rounded border border-line object-contain" />}
          {m.kind === 'video' && (src === 'mock'
            ? <div className="grid h-40 place-items-center rounded border border-line bg-base text-xs text-muted">Video payload mounted (demo file has no stream)</div>
            : <video src={src} controls preload="metadata" className="max-h-72 w-full rounded border border-line" />)}
          {m.kind === 'file' && src !== 'mock' && <a href={src} download={m.name} className="block rounded bg-electric py-2 text-center text-sm font-semibold text-white">Save {m.name}</a>}
          {m.kind === 'file' && src === 'mock' && <p className="text-xs text-muted">File payload received.</p>}
        </div>
      )}
    </div>
  );
}
