'use client';
import { useEffect, useRef } from 'react';
import type { Msg } from '@/lib/data';
import MediaBlock from './MediaBlock';

export default function Feed({ msgs, locked }: { msgs: Msg[]; locked: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { const el = ref.current; if (el) el.scrollTop = el.scrollHeight; }, [msgs.length]);

  if (locked)
    return (
      <div className="flex-1 space-y-4 overflow-hidden px-4 py-4" aria-hidden="true">
        {[60, 85, 40, 70, 55, 90, 45].map((w, i) => (
          <div key={i} className="flex gap-3"><span className="h-9 w-9 rounded-full bg-surface" /><div className="flex-1 space-y-2"><div className="h-3 w-24 rounded bg-surface" /><div className="h-3 rounded bg-surface" style={{ width: w + '%' }} /></div></div>
        ))}
      </div>
    );

  return (
    <div ref={ref} className="thin-scroll flex-1 overflow-y-auto py-2" role="log" aria-live="polite">
      {msgs.length === 0 && <p className="px-4 py-8 text-sm text-muted">Nothing here yet.</p>}
      {msgs.map((m) => (
        <div key={m.id} className="group flex items-start gap-3 px-4 py-1.5 hover:bg-surface/60">
          <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-surface text-sm font-semibold text-white">{m.author[0].toUpperCase()}</span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-white">{m.author}</p>
            {m.text && (
              <p className="flex items-baseline gap-3 text-[15px] leading-snug text-body">
                <span className="min-w-0 break-words">{m.text}</span>
                <time className="invisible shrink-0 text-[11px] text-muted group-hover:visible">{m.ts}</time>
              </p>
            )}
            {m.media && <div className="flex items-end gap-3"><MediaBlock m={m.media} /><time className="invisible pb-1 text-[11px] text-muted group-hover:visible">{m.ts}</time></div>}
          </div>
        </div>
      ))}
    </div>
  );
}
