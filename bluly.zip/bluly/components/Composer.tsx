'use client';
import { useRef, useState, type FormEvent } from 'react';
import Icon from './Icon';

export default function Composer({ readOnly, onText, onFile }: { readOnly: boolean; onText: (t: string) => void; onFile: (f: File) => void }) {
  const [v, setV] = useState('');
  const file = useRef<HTMLInputElement>(null);
  const submit = (e: FormEvent) => { e.preventDefault(); const t = v.trim(); if (!t) return; onText(t); setV(''); };

  return (
    <form onSubmit={submit} className="shrink-0 px-4 pb-4 pt-2">
      <div className={`flex h-12 items-center gap-1 rounded-full border border-line bg-surface px-2 focus-within:border-electric ${readOnly ? 'opacity-60' : ''}`}>
        <input ref={file} type="file" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = ''; }} />
        <button type="button" disabled={readOnly} aria-label="Attach file" onClick={() => file.current?.click()} className="grid h-9 w-9 place-items-center rounded-full text-body hover:text-white disabled:pointer-events-none"><Icon n="clip" /></button>
        <input value={v} onChange={(e) => setV(e.target.value)} disabled={readOnly} autoComplete="off" spellCheck={false} aria-label="Message"
          placeholder={readOnly ? 'Broadcast channel is read-only. Reply in a thread.' : 'Write a message'}
          className="h-full min-w-0 flex-1 bg-transparent px-2 text-[15px] text-white outline-none placeholder:text-muted focus-visible:outline-none" />
        <button type="submit" disabled={readOnly || !v.trim()} aria-label="Send" className="grid h-9 w-9 place-items-center rounded-full text-electric hover:text-white disabled:text-muted disabled:pointer-events-none"><Icon n="send" /></button>
      </div>
    </form>
  );
}
