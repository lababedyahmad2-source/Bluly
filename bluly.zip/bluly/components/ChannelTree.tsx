'use client';
import Link from 'next/link';
import { useState } from 'react';
import { CHANNELS, firstChannel, type Channel, type Server } from '@/lib/data';
import Icon from './Icon';

function Item({ c, active, indent, parentName }: { c: Channel; active: boolean; indent?: boolean; parentName?: string }) {
  return (
    <Link href={`/c/${c.serverId}/${c.id}`} aria-current={active ? 'page' : undefined}
      className={`flex items-center gap-1 rounded px-2 py-1.5 text-sm hover:bg-line/60 hover:text-white ${indent ? 'ml-4' : ''} ${active ? 'bg-line text-white' : 'text-body'}`}>
      <span className="text-muted">#</span>
      <span className="min-w-0 flex-1 truncate">{c.name}</span>
      {parentName && <span className="shrink-0 text-[11px] text-muted">{parentName}</span>}
      {!!c.urgent && !active && <span className="ml-1 grid min-w-[18px] place-items-center rounded-full bg-cyan px-1 text-[11px] font-bold leading-[18px] text-base">{c.urgent}</span>}
    </Link>
  );
}

export default function ChannelTree({ server, channelId, user }: { server: Server; channelId: string; user: string }) {
  const [menu, setMenu] = useState(false);
  const [mic, setMic] = useState(true);
  const [mute, setMute] = useState(false);
  const [copied, setCopied] = useState(false);
  const all = CHANNELS.filter((c) => c.serverId === server.id);
  const bc = all.filter((c) => c.kind === 'broadcast');
  const th = all.filter((c) => c.kind === 'thread');

  const copy = async () => {
    try { await navigator.clipboard.writeText(`${location.origin}/c/${server.id}/${firstChannel(server.id)}`); setCopied(true); } catch {}
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <aside className="flex h-dvh w-60 shrink-0 flex-col border-r border-line bg-surface">
      <div className="relative">
        <button onClick={() => setMenu((v) => !v)} aria-expanded={menu} className="flex h-14 w-full items-center gap-2 border-b border-line px-4 text-left hover:bg-line/40">
          <span className="truncate text-[15px] font-semibold text-white">{server.name}</span>
          {server.verified && <span title="Verified community" className="grid h-4 w-4 shrink-0 place-items-center rounded-full bg-cyan text-base"><Icon n="check" s={11} /></span>}
          <Icon n="chevron" s={16} className={`ml-auto text-muted ${menu ? 'rotate-180' : ''}`} />
        </button>
        {menu && (
          <div className="absolute inset-x-2 top-[60px] z-10 rounded-md border border-line bg-base p-1 text-sm">
            <button onClick={copy} className="w-full rounded px-2 py-1.5 text-left text-body hover:bg-line hover:text-white">{copied ? 'Invite link copied' : 'Copy invite link'}</button>
          </div>
        )}
      </div>

      <div className="thin-scroll flex-1 space-y-5 overflow-y-auto px-2 py-4">
        <section aria-label="Broadcast channels">
          <h2 className="mb-1 px-2 text-xs font-semibold text-muted">📢 Broadcast channels</h2>
          {bc.map((c) => <Item key={c.id} c={c} active={c.id === channelId} />)}
        </section>
        <section aria-label="Discussion threads">
          <h2 className="mb-1 px-2 text-xs font-semibold text-muted">💬 Discussion threads</h2>
          {th.length === 0 && <p className="px-2 text-xs text-muted">No threads yet.</p>}
          {th.map((c) => <Item key={c.id} c={c} indent active={c.id === channelId} parentName={all.find((p) => p.id === c.parent)?.name} />)}
        </section>
      </div>

      <div className="flex h-[52px] items-center gap-2 border-t border-line bg-base px-2">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-electric text-xs font-bold text-white">{(user || '?')[0].toUpperCase()}</span>
        <span className="min-w-0 flex-1 truncate text-sm font-medium text-white">{user || 'guest'}</span>
        <button aria-label="Microphone" aria-pressed={mic} onClick={() => setMic((v) => !v)} className={`grid h-8 w-8 place-items-center rounded hover:bg-line ${mic ? 'text-body' : 'text-cyan'}`}><Icon n="mic" off={!mic} /></button>
        <button aria-label="Audio mute" aria-pressed={mute} onClick={() => setMute((v) => !v)} className={`grid h-8 w-8 place-items-center rounded hover:bg-line ${mute ? 'text-cyan' : 'text-body'}`}><Icon n="vol" off={mute} /></button>
      </div>
    </aside>
  );
}
