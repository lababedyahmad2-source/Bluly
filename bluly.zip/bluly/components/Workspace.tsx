'use client';
import { useEffect, useMemo, useState } from 'react';
import { notFound } from 'next/navigation';
import { CHANNELS, SEED, SERVERS, fmtBytes, nowTs, type Msg } from '@/lib/data';
import { useSession } from '@/lib/session';
import HubRail from './HubRail';
import ChannelTree from './ChannelTree';
import Feed from './Feed';
import Composer from './Composer';
import AuthGate from './AuthGate';
import InstallPrompt from './InstallPrompt';
import Icon from './Icon';

export default function Workspace({ serverId, channelId }: { serverId: string; channelId: string }) {
  const { ready, authed, user, joined, join } = useSession();
  const server = SERVERS.find((s) => s.id === serverId);
  const channel = CHANNELS.find((c) => c.id === channelId && c.serverId === serverId);
  const [store, setStore] = useState<Record<string, Msg[]>>(SEED);
  const [drawer, setDrawer] = useState(false);
  const [sum, setSum] = useState(false);

  // Invited community mounts into the global hub stack as soon as the user is authenticated.
  useEffect(() => { if (authed && server && !joined.includes(server.id)) join(server.id); }, [authed, server, joined, join]);
  useEffect(() => { setDrawer(false); setSum(false); }, [serverId, channelId]);

  const msgs = store[channelId] ?? [];
  const bullets = useMemo(() => {
    const t = msgs.filter((m) => m.text).slice(-4).map((m) => `${m.author}: ${m.text!.length > 90 ? m.text!.slice(0, 87) + '…' : m.text}`);
    const media = msgs.filter((m) => m.media);
    if (media.length) t.push(`${media.length} media file${media.length > 1 ? 's' : ''} withheld (${fmtBytes(media.reduce((a, m) => a + m.media!.bytes, 0))} total, not downloaded)`);
    return t;
  }, [msgs]);

  if (!server || !channel) notFound();

  const push = (m: Omit<Msg, 'id' | 'ts' | 'author'>) =>
    setStore((s) => ({ ...s, [channelId]: [...(s[channelId] ?? []), { id: crypto.randomUUID(), author: user || 'you', ts: nowTs(), ...m }] }));
  const onFile = (f: File) => {
    const kind = f.type.startsWith('image/') ? 'image' : f.type.startsWith('video/') ? 'video' : 'file';
    push({ media: { kind, name: f.name, bytes: f.size, src: URL.createObjectURL(f) } }); // URL creation does not decode or load the file
  };
  const hubs = authed ? joined : [serverId];
  const locked = ready && !authed;
  const nav = (
    <>
      <HubRail active={serverId} hubs={hubs} />
      <ChannelTree server={server} channelId={channelId} user={user} />
    </>
  );

  return (
    <>
      <div inert={locked} aria-hidden={locked} className={`flex h-dvh w-full overflow-hidden bg-base ${locked ? 'select-none' : ''}`}>
        <div className="hidden md:flex">{nav}</div>

        <div className={`fixed inset-0 z-30 md:hidden ${drawer ? '' : 'pointer-events-none'}`}>
          <div onClick={() => setDrawer(false)} className={`absolute inset-0 bg-black/60 ${drawer ? 'opacity-100' : 'opacity-0'}`} />
          <div className={`drawer absolute left-0 top-0 flex h-full ${drawer ? 'translate-x-0' : '-translate-x-full'}`}>{nav}</div>
        </div>

        <main className="flex min-w-0 flex-1 flex-col bg-base">
          <header className="flex min-h-14 shrink-0 items-center gap-3 border-b border-line px-3 md:px-4">
            <button aria-label="Open channels" onClick={() => setDrawer(true)} className="grid h-9 w-9 place-items-center rounded text-body hover:bg-surface hover:text-white md:hidden"><Icon n="menu" s={22} /></button>
            <div className="min-w-0 flex-1 py-2">
              <h2 className="truncate text-[15px] font-semibold text-white"><span className="text-muted">#</span> {channel.name}</h2>
              <p className="truncate text-xs text-muted">{channel.purpose}</p>
            </div>
            <button onClick={() => setSum((v) => !v)} aria-pressed={sum} className={`flex h-9 items-center gap-2 rounded px-3 text-sm font-semibold ${sum ? 'bg-white text-base' : 'bg-electric text-white hover:bg-white hover:text-base'}`}>
              <Icon n="spark" s={16} /><span className="hidden sm:inline">AI Bullet Summary</span><span className="sm:hidden">Summary</span>
            </button>
            <InstallPrompt />
          </header>

          {sum && (
            <section aria-label="AI bullet summary" className="shrink-0 border-b border-line bg-surface px-4 py-3">
              <div className="mb-2 flex items-center justify-between"><h3 className="text-sm font-semibold text-white">Summary</h3>
                <button aria-label="Close summary" onClick={() => setSum(false)} className="text-muted hover:text-white"><Icon n="close" s={16} /></button></div>
              {bullets.length === 0 ? <p className="text-sm text-muted">Nothing to summarize yet.</p> :
                <ul className="space-y-1 text-sm text-body">{bullets.map((b, i) => <li key={i} className="flex gap-2"><span className="text-electric">•</span><span>{b}</span></li>)}</ul>}
            </section>
          )}

          <Feed msgs={msgs} locked={locked} />
          <Composer readOnly={channel.kind === 'broadcast'} onText={(text) => push({ text })} onFile={onFile} />
        </main>
      </div>
      {locked && <AuthGate server={server} channel={channel} />}
    </>
  );
}
