const P: Record<string, string> = {
  menu: 'M4 6h16M4 12h16M4 18h16',
  clip: 'M21 12.5l-8.6 8.6a5.5 5.5 0 01-7.8-7.8l9-9a3.7 3.7 0 015.2 5.2l-9 9a1.8 1.8 0 01-2.6-2.6l8.4-8.4',
  send: 'M3 11l18-8-8 18-2-8-8-2z',
  mic: 'M12 3a3 3 0 00-3 3v6a3 3 0 006 0V6a3 3 0 00-3-3zM5 11a7 7 0 0014 0M12 18v3',
  vol: 'M4 9v6h4l5 4V5L8 9H4zM17 8a5 5 0 010 8',
  user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  pulse: 'M3 12h4l3-8 4 16 3-8h4',
  lock: 'M6 11V8a6 6 0 0112 0v3M5 11h14v10H5z',
  chevron: 'M6 9l6 6 6-6',
  check: 'M5 12l5 5 9-10',
  image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M9 9h.01',
  video: 'M3 6h12v12H3zM15 10l6-3v10l-6-3',
  file: 'M6 3h8l4 4v14H6zM14 3v4h4',
  dl: 'M12 4v11M7 11l5 5 5-5M5 20h14',
  spark: 'M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z',
  close: 'M6 6l12 12M18 6L6 18',
};
export default function Icon({ n, s = 18, off = false, className = '' }: { n: keyof typeof P | string; s?: number; off?: boolean; className?: string }) {
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d={P[n]} />{off && <path d="M4 4l16 16" />}
    </svg>
  );
}
