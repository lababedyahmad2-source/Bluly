# Bluly
```
npm install
npm run dev     # http://localhost:3000  (redirects to /c/hq/announcements)
```
Try the invite flow: clear localStorage, open `/c/lab/rfc-12`, log in with any handle and a 4+ char key.
You land on that exact channel and "Open Source Lab" mounts in the hub rail.
PWA install needs `npm run build && npm start` (or HTTPS). Runtime deps: Next and React only.
