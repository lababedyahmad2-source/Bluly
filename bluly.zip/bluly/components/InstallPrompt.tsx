'use client';
import { useEffect, useState } from 'react';
import Icon from './Icon';

interface BIPEvent extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }

export default function InstallPrompt() {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [hint, setHint] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    if (matchMedia('(display-mode: standalone)').matches) setInstalled(true);
    const bip = (e: Event) => { e.preventDefault(); setEvt(e as BIPEvent); };
    const done = () => setInstalled(true);
    addEventListener('beforeinstallprompt', bip); addEventListener('appinstalled', done);
    return () => { removeEventListener('beforeinstallprompt', bip); removeEventListener('appinstalled', done); };
  }, []);

  if (installed) return null;
  const click = async () => {
    if (!evt) return setHint((v) => !v);
    await evt.prompt(); await evt.userChoice; setEvt(null);
  };
  return (
    <div className="relative">
      <button onClick={click} className="flex h-9 items-center gap-2 rounded border border-line px-3 text-sm text-body hover:border-electric hover:text-white">
        <Icon n="dl" s={16} /><span className="hidden sm:inline">Install Bluly</span><span className="sm:hidden">Install</span>
      </button>
      {hint && <p role="status" className="absolute right-0 top-11 z-20 w-56 rounded-md border border-line bg-surface p-3 text-xs text-body">Open your browser menu and choose “Install app” or “Add to Home Screen”.</p>}
    </div>
  );
}
