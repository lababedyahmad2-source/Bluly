'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

interface Session {
  ready: boolean; authed: boolean; user: string; joined: string[];
  login: (handle: string, serverId: string) => void; logout: () => void; join: (id: string) => void;
}
const Ctx = createContext<Session>(null!);
const KEY = 'bluly:v1';
export const useSession = () => useContext(Ctx);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState({ ready: false, user: '', joined: [] as string[] });

  useEffect(() => {
    try {
      const v = JSON.parse(localStorage.getItem(KEY) || 'null');
      setS({ ready: true, user: v?.user ?? '', joined: v?.joined ?? [] });
    } catch { setS((p) => ({ ...p, ready: true })); }
  }, []);

  const save = useCallback((user: string, joined: string[]) => {
    setS({ ready: true, user, joined });
    try { localStorage.setItem(KEY, JSON.stringify({ user, joined })); } catch {}
  }, []);

  const value = useMemo<Session>(() => ({
    ready: s.ready, authed: !!s.user, user: s.user, joined: s.joined,
    login: (h, sid) => save(h, Array.from(new Set(['hq', ...s.joined, sid]))),
    logout: () => save('', []),
    join: (id) => { if (!s.joined.includes(id)) save(s.user, [...s.joined, id]); },
  }), [s, save]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
