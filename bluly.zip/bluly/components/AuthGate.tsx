'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useSession } from '@/lib/session';
import type { Channel, Server } from '@/lib/data';
import Icon from './Icon';

const TARGET = 'bluly:target';
const field = 'mt-1.5 h-11 w-full rounded-md border border-line bg-base px-3 text-[15px] text-white outline-none placeholder:text-muted focus:border-electric focus:outline focus:outline-2 focus:outline-offset-0 focus:outline-electric';

export default function AuthGate({ server, channel }: { server: Server; channel: Channel }) {
  const { login } = useSession();
  const router = useRouter();
  const path = usePathname();
  const [handle, setHandle] = useState('');
  const [key, setKey] = useState('');
  const [err, setErr] = useState('');

  // Redirection memory: remember the exact invited channel before anything else happens.
  useEffect(() => { try { if (!sessionStorage.getItem(TARGET)) sessionStorage.setItem(TARGET, path); } catch {} }, [path]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!handle.trim() || key.length < 4) return setErr('Enter a handle and an invite key of at least 4 characters.');
    let target = path;
    try { target = sessionStorage.getItem(TARGET) || path; sessionStorage.removeItem(TARGET); } catch {}
    const sid = target.split('/')[2] || server.id;
    login(handle.trim(), sid); // mounts the invited community into the hub stack
    router.replace(target);
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-base/60 p-4 backdrop-blur-xl" role="dialog" aria-modal="true" aria-labelledby="gate-title">
      <form onSubmit={submit} className="w-full max-w-sm rounded-lg border border-line bg-surface p-6 shadow-2xl">
        <span className="grid h-11 w-11 place-items-center rounded-md border border-line bg-base text-electric"><Icon n="lock" s={22} /></span>
        <h1 id="gate-title" className="mt-4 text-xl font-semibold text-white">Private community</h1>
        <p className="mt-1 text-sm text-body">You were invited to <b className="text-white">{server.name}</b> #{channel.name}. Sign in to continue to that channel.</p>
        <label className="mt-5 block text-sm text-body">Handle
          <input value={handle} onChange={(e) => setHandle(e.target.value)} autoComplete="username" autoFocus placeholder="your-handle" className={field} />
        </label>
        <label className="mt-4 block text-sm text-body">Invite key
          <input value={key} onChange={(e) => setKey(e.target.value)} type="password" autoComplete="current-password" placeholder="••••••••" className={field} />
        </label>
        {err && <p role="alert" className="mt-3 text-sm text-cyan">{err}</p>}
        <button type="submit" className="mt-5 h-11 w-full rounded-md bg-electric text-[15px] font-semibold text-white hover:bg-white hover:text-base">Enter Bluly</button>
      </form>
    </div>
  );
}
