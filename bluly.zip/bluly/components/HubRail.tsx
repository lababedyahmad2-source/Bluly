'use client';
import Link from 'next/link';
import { useState } from 'react';
import { SERVERS, firstChannel } from '@/lib/data';
import Icon from './Icon';

export default function HubRail({ active, hubs }: { active: string; hubs: string[] }) {
  const [status, setStatus] = useState(false);
  return (
    <nav aria-label="Communities" className="relative flex h-dvh w-[72px] shrink-0 flex-col items-center border-r border-line bg-base py-3">
      <Link href="/" aria-label="Bluly" className="grid h-11 w-11 place-items-center rounded-md bg-electric text-xl font-bold text-white">B</Link>
      <div className="my-3 h-px w-8 bg-line" />
      <ul className="thin-scroll flex w-full flex-1 flex-col items-center gap-2 overflow-y-auto">
        {hubs.map((id) => {
          const sv = SERVERS.find((x) => x.id === id);
          if (!sv) return null;
          const on = id === active;
          return (
            <li key={id} className="relative flex w-full justify-center">
              {on && <span className="absolute left-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-r bg-electric" />}
              <Link href={`/c/${id}/${firstChannel(id)}`} title={sv.name} aria-label={sv.name} aria-current={on ? 'page' : undefined}
                className={`grid h-[50px] w-[50px] place-items-center text-sm font-semibold hover:rounded-xl hover:bg-electric hover:text-white ${on ? 'rounded-xl bg-electric text-white' : 'rounded-full bg-surface text-body'}`}>
                {sv.glyph}
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="relative flex flex-col items-center gap-2 pt-3">
        {status && (
          <div role="status" className="absolute bottom-0 left-[64px] z-20 w-52 rounded-md border border-line bg-surface p-3 text-xs text-body">
            <p className="font-semibold text-white">Infrastructure</p>
            <p className="mt-1">Edge: nominal</p><p>Media gate: enforced</p><p>Telemetry: off</p>
          </div>
        )}
        <button aria-label="Profile settings" className="grid h-10 w-10 place-items-center rounded-full bg-surface text-body hover:rounded-xl hover:text-white"><Icon n="user" /></button>
        <button aria-label="System status" aria-pressed={status} onClick={() => setStatus((v) => !v)}
          className="relative grid h-10 w-10 place-items-center rounded-full bg-surface text-body hover:rounded-xl hover:text-white">
          <Icon n="pulse" /><span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-electric" />
        </button>
      </div>
    </nav>
  );
}
